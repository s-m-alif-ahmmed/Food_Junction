 <!-- JQUERY JS -->
 <script src="{{ asset('backend') }}/plugins/jquery/jquery.min.js"></script>

 <!-- BOOTSTRAP JS -->
 <script src="{{ asset('backend') }}/plugins/bootstrap/js/popper.min.js"></script>
 <script src="{{ asset('backend') }}/plugins/bootstrap/js/bootstrap.min.js"></script>

 <!-- Perfect SCROLLBAR JS-->
 <script src="{{ asset('backend') }}/plugins/p-scroll/perfect-scrollbar.js"></script>

 <!-- STICKY JS -->
 <script src="{{ asset('backend') }}/js/sticky.js"></script>



 <!-- COLOR THEME JS -->
 <script src="{{ asset('backend') }}/js/themeColors.js"></script>

 <!-- CUSTOM JS -->
 <script src="{{ asset('backend') }}/js/custom.js"></script>

 <!-- SWITCHER JS -->
 <script src="{{ asset('backend') }}/switcher/js/switcher.js"></script>
