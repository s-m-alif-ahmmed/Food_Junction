{{--Bootstrap 5--}}
<link rel="stylesheet" href="{{ asset('/frontend/assets/bootstrap/css/bootstrap.min.css') }}">
{{--style--}}
<link rel="stylesheet" href="{{ asset('/frontend/assets/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('/frontend/assets/css/responsive.css') }}">

{{--Fontawesome--}}
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

{{--Font--}}
<link rel="stylesheet" href="{{ asset('/frontend/assets/font/nirmala-ui/Nirmala.ttf') }}">

{{--Toast--}}
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

