@extends('frontend.master')

@section('meta_infos')
    <meta name="author" content="Food Junction">
    <meta name="description" content="Food Junction">
    <meta name="keywords" content="Food Junction, Food, Junction, Dhaka, Sweets">
@endsection

@section('title')
    Blog | Food Junction
@endsection

@section('content')

    @include('frontend.includes.top-nav-button')

    <section class="sweet-page">

        <div class="container-fluid pb-3">
            <div class="row">
                <div class="col-lg-12 section-heading background-gradient">
                    <p class="heading-text">Blog</p>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row pt-3 pb-5">

                @forelse($blogs as $blog)
                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 mb-4">
                        <div class="card">
                            <img src="{{ asset($blog->image ?? 'frontend/images/section/home/blog.png') }}" class="card-img-top object-fit-fill" style="height: 200px;" alt="...">
                            <div class="card-body">
                                <h5 class="card-title mb-3">{{ $blog->title }}</h5>
                                <a href="{{ route('blog.detail', $blog->slug) }}" class="order-now-btn w-auto fw-bold">Read More</a>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="col-12 text-center py-5">
                        <p class="fs-20 text-muted">No blog posts available now!</p>
                    </div>
                @endforelse

                <div class="">
                    {{ $blogs->links('pagination::bootstrap-5') }}
                </div>
            </div>
        </div>
    </section>

@endsection
