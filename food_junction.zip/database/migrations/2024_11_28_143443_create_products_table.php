<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasTable('products')) {
            Schema::create('products', function (Blueprint $table) {
                $table->id();
                $table->string('meta_title')->nullable();
                $table->string('meta_description')->nullable();
                $table->text('meta_keywords')->nullable();
                $table->foreignId('category_id')->nullable()->constrained('categories')->onDelete('cascade');
                $table->string('name')->nullable();
                $table->text('description')->nullable();
                $table->text('image')->nullable();
                $table->enum('type', ['pcs', 'gram']);
                $table->string('product_slug')->nullable();
                $table->enum('status',['active','inactive'])->default('active');
                $table->timestamps();
                $table->softDeletes();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
