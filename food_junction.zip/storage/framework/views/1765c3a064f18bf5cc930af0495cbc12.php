<?php
$categories = \App\Models\Category::where('status', 'active')->latest()->get()
?>

<div class="container d-lg-block d-md-none d-sm-none d-none">
    <div class="row">
        <ul class="navbar-nav navbar categories">
            <li class="nav-item">
                <a href="<?php echo e(route('products')); ?>" class="nav-link">
                    All Categories
                </a>
            </li>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('category.products', $category->category_slug)); ?>" class="nav-link">
                        <?php echo e($category->name); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH G:\Herd\Sijan\food_junction\resources\views/frontend/includes/category-menu.blade.php ENDPATH**/ ?>