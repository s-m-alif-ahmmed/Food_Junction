<?php $__env->startSection('meta_infos'); ?>
    <meta name="author" content="Food Junction">
    <meta name="description" content="Food Junction">
    <meta name="keywords" content="Food Junction, Food, Junction, Dhaka, Sweets">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="user-dashboard-page">
        <div class="container-fluid">
            <div class="row background-gradient">
                <div class="col-md-12 text-center">
                    <p class="text-uppercase fw-bold text-white mt-3 mb-0 fs-32">My Profile</p>
                    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%23ffffff'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-decoration-none text-white">Home</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">My Profile</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row py-3">
                <div class="col-12">

                    <!-- Tab Navigation -->
                    <ul class="nav nav-tabs" id="profileTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link text-black active" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="true">Profile</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link text-black" id="order-history-tab" data-bs-toggle="tab" data-bs-target="#order-history" type="button" role="tab" aria-controls="order-history" aria-selected="false">Order History</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link text-black" id="wishlist-tab" data-bs-toggle="tab" data-bs-target="#wishlist" type="button" role="tab" aria-controls="wishlist" aria-selected="false">My Wishlist</button>
                        </li>
                    </ul>

                    <div class="tab-content p-3 border border-top-0" id="profileTabContent">
                        <!-- Profile Tab -->
                        <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">

                            <form action="<?php echo e(route('user.update.profile')); ?>" method="POST" class="row">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>

                                <p class="fs-20 fsw-bold text-red">Edit Your Profile</p>

                                <div class="col-md-12">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" name="name" value="<?php echo e(Auth::user()->name); ?>" id="name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error-message"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-12">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" value="<?php echo e(Auth::user()->email); ?>" id="email">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error-message"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-12 py-3 text-center">
                                    <button type="submit" class="btn background-gradient border-0 text-white fsw-bold">Save Changes</button>
                                </div>

                            </form>

                            <form action="<?php echo e(route('user.update.profile.password')); ?>" method="POST" class="row">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>

                                <p class="fs-20 fsw-bold text-red pt-3">Change Password</p>

                                <div class="col-md-12">
                                    <label for="current_password" class="form-label">Current Password</label>
                                    <input type="password" class="form-control" name="current_password" value="" id="current_password">
                                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error-message"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12">
                                    <label for="password" class="form-label">New Password</label>
                                    <input type="password" class="form-control" name="password" value="" id="password">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error-message"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12">
                                    <label for="password_confirmation" class="form-label">Confirm Password</label>
                                    <input type="password" class="form-control" name="password_confirmation" value="" id="password_confirmation">
                                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error-message"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-12 py-3 text-center">
                                    <button type="submit" class="btn background-gradient border-0 text-white fsw-bold">Change Password</button>
                                </div>
                            </form>
                        </div>
                        <!-- Order History Tab -->
                        <div class="tab-pane fade" id="order-history" role="tabpanel" aria-labelledby="order-history-tab">
                            <p class="fs-20 fsw-bold">Order History</p>
                            <?php if($orders->isNotEmpty()): ?>

                                <div  class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th scope="col">Tracking ID</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Address</th>
                                            <th scope="col">Number</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Total</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row">
                                                    <a href="<?php echo e(route('order.details', $order->tracking_id)); ?>" class="text-black text-decoration-none">
                                                        <?php echo e($order->tracking_id); ?>

                                                    </a>
                                                </th>
                                                <td>
                                                    <?php echo e($order->name); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($order->email); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($order->address); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($order->number); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($order->status); ?>

                                                </td>
                                                <td>
                                                    <?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d M, Y h:i a')); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                            <?php else: ?>
                                <p>No orders found.</p>
                            <?php endif; ?>

                        </div>
                        <!-- Wishlist Tab -->
                        <div class="tab-pane fade" id="wishlist" role="tabpanel" aria-labelledby="wishlist-tab">
                            <p class="fs-20 fsw-bold">My Wishlist</p>
                            <?php if($wishlists->count() > 0): ?>
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">Product Image</th>
                                        <th scope="col">Product Name</th>
                                        <th scope="col">Price</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row">
                                                <a href="<?php echo e(route('product.detail', $wishlist->product->product_slug)); ?>" class="text-black text-decoration-none">
                                                    <img class="img-fluid" style="height: 50px;" src="<?php echo e($wishlist->product->image); ?>" alt="<?php echo e($wishlist->product->name); ?>">
                                                </a>
                                            </th>
                                            <th scope="row">
                                                <a href="<?php echo e(route('product.detail', $wishlist->product->product_slug)); ?>" class="text-black text-decoration-none">
                                                    <?php echo e($wishlist->product->name); ?>

                                                </a>
                                            </th>
                                            <td>
                                                <?php echo e($wishlist->product->price); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p>Your wishlist is empty.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // Trigger toaster based on session messages
        <?php if(session('t-success')): ?>
        showSuccessToast("<?php echo e(session('t-success')); ?>");
        <?php endif; ?>

        <?php if(session('t-error')): ?>
        showErrorToast("<?php echo e(session('t-error')); ?>");
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Herd\Sijan\food_junction\resources\views/frontend/dashboard/dashboard.blade.php ENDPATH**/ ?>