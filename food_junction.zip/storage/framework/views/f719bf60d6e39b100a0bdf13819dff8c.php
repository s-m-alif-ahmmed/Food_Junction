<div class="top-message">
    <div class="whats-app">
        আমাদের যে কোন পণ্য অর্ডার করতে কল বা WhatsApp করুন: <a class="text-decoration-none text-white" href="https://api.whatsapp.com/send?phone=01607022072" target="_blank">01607022072</a> | হটলাইন
        নাম্বার - <a class="text-decoration-none text-white" href="tel:01607022072" target="_blank">01607022072</a>
    </div>
</div>

<div class="top-message-mobile">
    <div class="whats-app">
        আমাদের যে কোন পণ্য অর্ডার করতে কল বা
        <br />
        WhatsApp করুন: <a class="text-decoration-none text-white" href="https://api.whatsapp.com/send?phone=01607022072" target="_blank">01607022072</a> | হটলাইন নাম্বার - <a class="text-decoration-none text-white" href="tel:01607022072" target="_blank">01607022072</a>
    </div>
</div>



<?php /**PATH G:\Herd\Sijan\food_junction\resources\views/frontend/includes/top-header.blade.php ENDPATH**/ ?>