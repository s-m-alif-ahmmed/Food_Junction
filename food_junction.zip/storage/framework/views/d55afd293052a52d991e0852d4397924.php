<?php $__env->startSection('meta_infos'); ?>
    <meta name="author" content="Food Junction">
    <meta name="description" content="Food Junction">
    <meta name="keywords" content="Food Junction, Food, Junction, Dhaka, Sweets">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($category->name); ?> - Products | Food Junction
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.includes.top-nav-button', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="sweet-page">

        <div class="container-fluid pb-3">
            <div class="row">
                <div class="col-lg-12 section-heading background-gradient">
                    <p class="heading-text"><?php echo e($category->name); ?></p>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="row py-3">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-6 special-sweet-card">
                            <div class="card border-0 custom-shadow">
                                <div class="sweet-image">
                                    <img src="<?php echo e(asset($product->image ?? '/frontend/images/section/home/harivanga-mishti-500x500.jpg')); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                                </div>
                                <div class="card-body border-0 mb-3 h-100">
                                    <h5 class="fsw-bold"><?php echo e($product->name); ?></h5>
                                    <p class="fsw-semibold"><?php echo e($product->price); ?> টাকা ( <span class="text-danger"><del>৮৫০ টাকা</del></span> )</p>
                                    <a href="<?php echo e(route('product.detail', $product->product_slug)); ?>" class="order-now-btn w-auto fw-bold">Order Now</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="">
                        <?php echo e($products->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Herd\Sijan\food_junction\resources\views/frontend/pages/product-category.blade.php ENDPATH**/ ?>