 <!-- JQUERY JS -->
 <script src="<?php echo e(asset('backend')); ?>/plugins/jquery/jquery.min.js"></script>

 <!-- BOOTSTRAP JS -->
 <script src="<?php echo e(asset('backend')); ?>/plugins/bootstrap/js/popper.min.js"></script>
 <script src="<?php echo e(asset('backend')); ?>/plugins/bootstrap/js/bootstrap.min.js"></script>

 <!-- Perfect SCROLLBAR JS-->
 <script src="<?php echo e(asset('backend')); ?>/plugins/p-scroll/perfect-scrollbar.js"></script>

 <!-- STICKY JS -->
 <script src="<?php echo e(asset('backend')); ?>/js/sticky.js"></script>



 <!-- COLOR THEME JS -->
 <script src="<?php echo e(asset('backend')); ?>/js/themeColors.js"></script>

 <!-- CUSTOM JS -->
 <script src="<?php echo e(asset('backend')); ?>/js/custom.js"></script>

 <!-- SWITCHER JS -->
 <script src="<?php echo e(asset('backend')); ?>/switcher/js/switcher.js"></script>
<?php /**PATH G:\Herd\Sijan\food_junction\resources\views/auth/partials/scripts.blade.php ENDPATH**/ ?>