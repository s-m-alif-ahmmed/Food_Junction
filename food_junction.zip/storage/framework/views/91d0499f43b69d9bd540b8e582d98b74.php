<?php $__env->startSection('meta_infos'); ?>
    <meta name="author" content="Food Junction">
    <meta name="description" content="Food Junction">
    <meta name="keywords" content="Food Junction, Food, Junction, Dhaka, Sweets">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Blog Detail | Food Junction
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.includes.top-nav-button', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="sweet-page">

        <div class="container-fluid pb-3">
            <div class="row">
                <div class="col-lg-12 section-heading background-gradient">
                    <p class="heading-text">Blog Detail</p>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row pt-3 pb-5">
                <div class="col-md-9">
                    <div class="">
                        <img class="img-fluid rounded-2 w-100" src="<?php echo e(asset($blog->image ?? 'frontend/images/section/home/blog.png')); ?>" alt="">
                    </div>
                    <div>
                        <p class="p-2">Published At: <?php echo e($blog->created_at->diffForHumans()); ?></p>
                    </div>
                    <div class="">
                        <h1><?php echo e($blog->title); ?></h1>
                        <p>
                            <?php echo $blog->description; ?>

                        </p>
                    </div>
                    <div class="text-center">
                        <h2 class="styled-heading">Comments (<?php echo e($blog_comments->count()); ?>)</h2>
                        <div class="text-underline"></div>
                    </div>
                    <div class="">
                        <div class="">
                            <?php $__currentLoopData = $blog_comments->take(20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex mb-2">
                                    <div class="me-2">
                                        <img class="rounded-circle" style="height: 50px;" src="<?php echo e(asset($comment->user->avatar ?? 'frontend/images/default/profile-avatar.png')); ?>" alt="">
                                    </div>
                                    <div class="">
                                        <p class="m-0"><?php echo e($comment->user->name ?? 'Anonymous'); ?></p>
                                        <p class="m-0"><?php echo e($comment->created_at->diffForHumans()); ?></p>
                                    </div>
                                </div>
                                <div class="">
                                    <p>
                                        <?php echo $comment->comment; ?>

                                    </p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="">
                                <form action="<?php echo e(route('comment.store', ['blogId' => $blog->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <textarea class="rounded-2" style="border: 1px solid #7d7e7e;" name="comment" id="" cols="30" rows="3"></textarea>
                                    <button type="submit" class="btn review-btn float-end">Send</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 border rounded-2 h-100">
                    <div class="">
                        <p class="fs-32 fw-semibold">Latest Blog</p>
                    </div>
                    <div class="">
                        <?php $__currentLoopData = $latest_blogs->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex mb-2">
                                <div class="me-2">
                                    <a class="nav-link" href="<?php echo e(route('blog.detail', $data->slug)); ?>">
                                        <img class="rounded-circle object-fit-cover" style="height: 75px; width: 75px;" src="<?php echo e(asset($data->image ?? 'frontend/images/section/home/blog.png')); ?>" alt="">
                                    </a>
                                </div>
                                <div class="">
                                    <p class="m-0">
                                        <a class="nav-link" href="<?php echo e(route('blog.detail', $data->slug)); ?>">
                                            <?php echo e($data->title); ?>

                                        </a>
                                    </p>
                                    <p class="m-0"><?php echo e($data->created_at->diffForHumans()); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Herd\Sijan\food_junction\resources\views/frontend/pages/blog-detail.blade.php ENDPATH**/ ?>