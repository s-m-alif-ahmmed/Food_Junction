<?php $__env->startSection('meta_infos'); ?>
    <meta name="author" content="Food Junction">
    <meta name="description" content="Food Junction">
    <meta name="keywords" content="Food Junction, Food, Junction, Dhaka, Sweets">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    FAQ | Food Junction
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .accordion .accordion-item {
            border-top: none;
            border-left: none;
            border-right: none;
            border-bottom: none;
        }
        .accordion .accordion-item .accordion-header {
            border-bottom: 2px solid var(--red);
        }
        .accordion .accordion-item .accordion-header .accordion-button {
            background-color: white;
            padding: 10px 5px ;
        }
        .accordion .accordion-item .accordion-header .accordion-button:focus {
            box-shadow: none;
            outline: none;
        }
        .accordion .accordion-item .accordion-body {
            padding: 10px 5px ;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <section class="sweet-page">

        <div class="container-fluid pb-3">
            <div class="row">
                <div class="col-lg-12 section-heading background-gradient">
                    <p class="heading-text">FAQ</p>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row justify-content-center py-5">
                <div class="col-md-8 col-sm-12 col-12">
                    <div class="accordion" id="accordionExample">
                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading<?php echo e($faq->id); ?>">
                                    <button class="accordion-button <?php echo e($index === 0 ? '' : 'collapsed'); ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($faq->id); ?>" aria-expanded="<?php echo e($index === 0 ? 'true' : 'false'); ?>" aria-controls="collapse<?php echo e($faq->id); ?>">
                                        <?php echo e($faq->question); ?>

                                    </button>
                                </h2>
                                <div id="collapse<?php echo e($faq->id); ?>" class="accordion-collapse collapse <?php echo e($index === 0 ? 'show' : ''); ?>" aria-labelledby="heading<?php echo e($faq->id); ?>" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p><?php echo e($faq->answer); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Herd\Sijan\food_junction\resources\views/frontend/pages/faq.blade.php ENDPATH**/ ?>