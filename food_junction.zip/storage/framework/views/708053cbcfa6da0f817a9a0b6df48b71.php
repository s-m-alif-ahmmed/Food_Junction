
<link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/bootstrap/css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/responsive.css')); ?>">


<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">


<link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/font/nirmala-ui/Nirmala.ttf')); ?>">


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

<?php /**PATH G:\Herd\Sijan\food_junction\resources\views/frontend/includes/css.blade.php ENDPATH**/ ?>