<?php $__env->startSection('meta_infos'); ?>
    <meta name="author" content="Food Junction">
    <meta name="description" content="Food Junction">
    <meta name="keywords" content="Food Junction, Food, Junction, Dhaka, Sweets">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Food Junction
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.includes.top-nav-button', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="hero-section">

        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 p-0">
                    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $home_banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                                    <img src="<?php echo e(asset( $image->image ?? '/frontend/images/section/home/hero_banner.png')); ?>" class="d-block w-100" alt="...">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid pb-3">
            <div class="row">
                <div class="col-lg-12 section-heading background-gradient">
                    <p class="heading-text">Offer Products</p>
                </div>
            </div>
        </div>

        <div class="container pb-5">
            <div class="row py-3">
                <?php $__currentLoopData = $products->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-6 special-sweet-card">
                        <div class="card border-0 custom-shadow">
                            <div class="sweet-image">
                                <img src="<?php echo e(asset($product->image ?? '/frontend/images/section/home/harivanga-mishti-500x500.jpg')); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                            </div>
                            <div class="card-body border-0 mb-3 h-100">
                                <h5 class="fsw-bold"><?php echo e($product->name); ?></h5>
                                <p class="fsw-semibold"><?php echo e($product->price); ?> টাকা ( <span class="text-danger"><del>৮৫০ টাকা</del></span> )</p>
                                <a href="<?php echo e(route('product.detail', $product->product_slug)); ?>" class="order-now-btn w-auto fw-bold">Order Now</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="container-fluid pb-3">
            <div class="row">
                <div class="col-lg-12 section-heading background-gradient">
                    <p class="heading-text">All Products</p>
                </div>
            </div>
        </div>

        <div class="container pb-5">
            <div class="row py-3">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-6 special-sweet-card">
                        <div class="card border-0 custom-shadow">
                            <div class="sweet-image">
                                <img src="<?php echo e(asset($product->image ?? '/frontend/images/section/home/harivanga-mishti-500x500.jpg')); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                            </div>
                            <div class="card-body border-0 mb-3 h-100">
                                <h5 class="fsw-bold"><?php echo e($product->name); ?></h5>
                                <p class="fsw-semibold"><?php echo e($product->price); ?> টাকা ( <span class="text-danger"><del>৮৫০ টাকা</del></span> )</p>
                                <a href="<?php echo e(route('product.detail', $product->product_slug)); ?>" class="order-now-btn w-auto fw-bold">Order Now</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="container-fluid p-0 m-0 overflow-hidden bottom-banner">
            <div class="row">
                <div class="cta-footer">
                    <div class="cta">
                        <img class="image img-fluid w-100" src="<?php echo e(asset( $home_bottom_banner->image ?? 'frontend/images/section/home/bottom-banner.png')); ?>" />
                        <div class="text"><?php echo e($home_bottom_banner->title ?? 'Are you ready to order with the best deals?'); ?></div>
                        <a href="<?php echo e(route('products')); ?>" class="button">
                            <div class="text2">Proceed to order</div>
                            <div class="icon">
                                <img src="<?php echo e(asset('frontend/images/icons/arrow.svg')); ?>" alt="">
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Herd\Sijan\food_junction\resources\views/frontend/pages/index.blade.php ENDPATH**/ ?>